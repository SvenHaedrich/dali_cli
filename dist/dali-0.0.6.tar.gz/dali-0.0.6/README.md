# DALI cli

Command line interface to control a DALI system.

DALI is the digital addressable lighting interface as described [here](https://www.dali-alliance.org).

## Install

```
git clone git@github.com:SvenHaedrich/dali_cli.git
cd dali_cli
python3 -m venv venv
```